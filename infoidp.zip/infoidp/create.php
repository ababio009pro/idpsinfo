<?php 
  require ("db.php");
   if(isset($_POST["DonateNow"]))
   {
    if(empty($_POST["amount"]) || empty($_POST["firstname"]))
    {
      $msg = "amount and firstname require"; 
    }
      else
      {
        //do nothing here enter try and catch something eeehehehe!

   $collect="m-";
   $donateID= uniqid($collect); 
   $amount = $_POST["amount"];
   $firstname = $_POST["firstname"];
   $lastname = $_POST["lastname"];
   $phone = $_POST["phone"];
   $location = $_POST["location"];
   $address = $_POST["address"];
   $additionalNote = $_POST["additionalNote"]; 
   $y=date("y");
   $m=date("m");

    // our SQL statements
   $sql="INSERT INTO donations (donateID,amount, firstname, lastname, phone, location, address, additionalNote,month,year)
    VALUES (:donateID, :amount,:firstname,:lastname,:phone,:location,:address,:additionalNote,:m,:y)";
    $stmt=$connect->prepare($sql);
 if($stmt->execute([":donateID"=>$donateID, ":amount"=>$amount, ":firstname"=>$firstname, ":lastname"=>$lastname, ":phone"=>$phone, ":location"=>$location, ":address"=>$address, ":additionalNote"=>$additionalNote,":m"=>$m,":y"=>$y])){
   echo "<script>
          alert('Thanks for donating to us, click OK to continue');
          window.location.href='index.php';
        </script>";
 }}}
 
 ?>