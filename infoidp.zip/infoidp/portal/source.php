<?php 
// include database connection 
include "db.php"; 
 
// select the image 
$query = "select photo from idp WHERE idp_Id = idp_Id"; 
$stmt = $connect->prepare( $query );
 
// bind the id of the image you want to select
$stmt->bindParam(1, $_GET['idp_Id']);
$stmt->execute();
 
// to verify if a record is found
$num = $stmt->rowCount();
 
if( $num ){
    // if found
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // specify header with content type,
    // you can do header("Content-type: image/jpg"); for jpg,
    // header("Content-type: image/gif"); for gif, etc.
    header("Content-type: upload/Idps/1567009005.jpg");
    
    //display the image data
    print $row['data'];
    exit;
}else{
    //if no image found with the given id,
    //load/query your default image here
}
?>