<?php
	include 'db.php';
	//Start session
	session_start();
	
	//Check whether the session variable SESS_MEMBER_ID is present or not
	if(!isset($_SESSION['SESS_MEMBER_ID']) || (trim($_SESSION['SESS_MEMBER_ID']) == '')) {
		// do nothing
		header("location:dashboard.php");
		exit();
	}

	$session_id  = $_SESSION['SESS_MEMBER_ID'];

	$query = $connect->prepare("SELECT * FROM user WHERE id = ?");
	$query->execute(array($session_id));
	$row = $query->fetch();

	$session_admin_name = $row['firstname'];
?>