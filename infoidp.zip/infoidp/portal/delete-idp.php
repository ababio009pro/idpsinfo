<?php
require'db.php';
$idp_Id=$_GET['idp_Id'];
$sql='DELETE FROM idp where idp_Id=:idp_Id';
$statement=$connect->prepare($sql);
if($statement->execute(['idp_Id'=>$idp_Id])
){
	
      echo "<script>
              alert('Deleted!!!, click OK to continue');
              window.location.href='allidps.php';
             </script>";                    
	//header("location:viewall.php");
}

?>