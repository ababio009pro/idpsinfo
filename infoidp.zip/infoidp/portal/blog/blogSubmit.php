<?php
    session_start();

	require 'db.php';

	if(!isset($_SESSION['']) OR $_SESSION['role'] == 0)
	{
		$_SESSION['message'] = "You need to first login to write a blog !!!";
		header("Location: ../Login/error.php");
		die();
	}


	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		$Blogid= $_POST['post'];
		$Blogtitle = dataFilter($_POST['blogTitle']);
		$Blogcontent = $_POST['blogContent'];
		$Blogauthor = $_SESSION['role'];
		$Blogcategory = $_POST['BlogCategory'];
		$Blogtags = $_POST['BlogTags'];
		$Blogtime =getdate();
	}


    $sql = "INSERT INTO blog (blogid, blogAuthor, blogTitle, blogContent, BlogTime, BlogCategory, BlogTags)
		    VALUES ('$Blogid', '$Blogauthor', '$Blogtitle','$Blogcontent', '$Blogtime','$Blogcategory', '$Blogtags')";
    $result = mysqli_query($connect, $sql);

    if(!$result)
    {
        $_SESSION['message'] = "Some Error occurred !!!";
        header("location: ../Login/error.php");
    }
	else
	{  
		echo "Event Posted Successfully";
		header("Location: ../blogView.php");
	}

    function dataFilter($data)
    {
    	$data = trim($data);
     	$data = stripslashes($data);
    	$data = htmlspecialchars($data);
      	return $data;
    }

?>
