<?php
	session_start();

	require 'db.php';

    $sql = "SELECT * FROM blog ORDER BY blogId DESC";
    $result = mysqli_query($connect, $sql);

    while($row = $result->fetch_array()):
?>

        <?= $row['likes']; ?>

    <?php endwhile; ?>
