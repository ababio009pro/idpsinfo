<?php
session_start();
$username=$_SESSION['username'];
$role=$_SESSION['role'];
?>
<?php 
try{
  require"db.php";
$sql='SELECT * FROM idp';
$agam='SELECT location FROM idp WHERE location="agam"';
$abegena='SELECT location FROM idp WHERE location="abegena"';
$ichwa='SELECT location FROM idp WHERE location="ichwa"';
$statement=$connect->prepare($sql);
$statement2=$connect->prepare($agam);
$statement3=$connect->prepare($abegena);
$statement4=$connect->prepare($ichwa);
$statement->execute();
$statement2->execute();
$statement3->execute();
$statement4->execute();
$people=$statement->fetchAll(PDO::FETCH_OBJ);
$people2=$statement2->fetchAll(PDO::FETCH_OBJ);
$people3=$statement3->fetchAll(PDO::FETCH_OBJ);
$people4=$statement4->fetchAll(PDO::FETCH_OBJ);
$total=$statement->rowCount();
$agam=$statement2->rowCount();
$abegena=$statement3->rowCount();
$ichwa=$statement4->rowCount();

}catch(PDOException $e){
  echo('i don catch').$e->getmessage();
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Benue IDPS Information System">
  <meta name="author" content="ababio009">
  <meta name="keyword" content="IDPS, Donations, Children, Elderly, Information, System, Information System">
  
  <title>All IDPS|  IDPS- Information System  </title>

  <link rel="shortcut icon" href="img/logo.jpg">
  <!-- Bootstrap CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- bootstrap theme -->
  <link href="css/bootstrap-theme.css" rel="stylesheet">
  <!--external css-->
  <!-- font icon -->
  <link href="css/elegant-icons-style.css" rel="stylesheet" />
  <link href="css/font-awesome.min.css" rel="stylesheet" />
  <!-- full calendar css-->
  <link href="assets/fullcalendar/fullcalendar/bootstrap-fullcalendar.css" rel="stylesheet" />
  <link href="assets/fullcalendar/fullcalendar/fullcalendar.css" rel="stylesheet" />
  <!-- easy pie chart-->
  <link href="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen" />
  <!-- owl carousel -->
  <link rel="stylesheet" href="css/owl.carousel.css" type="text/css">
  <link href="css/jquery-jvectormap-1.2.2.css" rel="stylesheet">
  <!-- date -->
  <link href="css/daterangepicker.css" rel="stylesheet" />
  <link href="css/bootstrap-datepicker.css" rel="stylesheet" />
  <link href="css/bootstrap-colorpicker.css" rel="stylesheet" />
  <!-- Custom styles -->
  <link rel="stylesheet" href="css/fullcalendar.css">
  <link href="css/widgets.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet" />
  <link href="css/xcharts.min.css" rel=" stylesheet">
  <link href="css/jquery-ui-1.10.4.min.css" rel="stylesheet">
</head>

<body>

  <!-- container section start -->
  <section id="container" class="">
  
    <header class="header dark-bg">
      <div class="toggle-nav">
        <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"><i class="icon_menu"></i></div>
      </div>

      <!--logo start-->
      <a href="dashboard.php" class="logo">IDPS<span class="lite">Portal</span></a>
      <!--logo end-->

      <div class="nav search-row" id="top_menu">
        <!--  search form start -->
        <ul class="nav top-menu">
          <li>
            <form class="navbar-form">
              <input class="form-control" placeholder="Search" type="text">
            </form>
          </li>
        </ul>
        <!--  search form end -->
      </div>

      <div class="top-nav notification-row">
        <!-- notificatoin dropdown start-->
        <ul class="nav pull-right top-menu">

          <!-- task notificatoin start -->
          <li id="task_notificatoin_bar" class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                
          <!-- alert notification end-->
          <!-- user login dropdown start-->
          <li class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="profile-ava">
                                <img alt="" src="img/avatar1_small.jpg">
                            </span>
                            <span class="username"><b id="welcome">Welcome : <i><?php echo $_SESSION['username'];?></i></b></span>
                            <b class="caret"></b>
                        </a>
            <ul class="dropdown-menu extended logout">
              <div class="log-arrow-up"></div>
              <li class="eborder-top">
                <a href="#"><i class="icon_profile"></i> My Profile</a>
              </li>
              <li class="eborder-top">
                <a href="logout.php"><i class="icon_key_alt"></i> Log Out</a>
              </li>
              <li>
                <a href="documentation.html"><i class="icon_key_alt"></i> Documentation</a>
              </li>
          </li>
          <!-- user login dropdown end -->
        </ul>
        <!-- notificatoin dropdown end-->
      </div>
    </header>
    <!--header end-->
    
    <!--header end-->

 <?php

 if($role=='admin'){
  require("sidenav.php");
} else if($role=='registrar'){
  require("sidenav_registrar.php");
}else{
  require("sidenav_staff.php");
}

?>
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        <!--overview start-->
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa-laptop"></i> IDPS and Location</h3>
            <ol class="breadcrumb">
              <li><i class="fa fa-home"></i><a href="dashboard.php">Home</a></li>
              <li><i class="fa fa-laptop"></i>Idps</li>
            </ol>
          </div>
        </div>
     <!-- container section start -->
            <section class="panel">
              <header class="panel-heading">
              <div id="page-wrapper">
                <div class="container-fluid">
                   <div class="row">
                      <div class="col-lg-12">
                    <h1 class="page-header" align="center">IDPS Location Report Sheet</h1>
                </div>
                <div id="maintable">
                    <div style="margin-top: -19px; margin-bottom: 21px;">
                    </div>

              <table class="table table-striped table-advance table-hover">
                <div class="table-responsive">
                <table class="table">
                  <div align="left"> <a href="" onclick="window.print()" class="btn btn-primary" ><i class="icon-print icon-large"></i> Print</a></div>
                <tbody>
                  <tr>
                    <th><i class="icon_key_alt"></i> S/N</th>
                    <th>Firstname</th>
                    <th>Middlename</th>
                    <th>Lastname</th>
                    <th>Gender</th>
                    <th>Location</th>
                    <!--<th><i class="icon_cogs"></i> Action</th>-->
                    <?php foreach ($people as $key => $me): ?>
                  </tr>
                  <tr>
                    <td><?php echo "$key"; ?></td>
                    <td><?= $me->firstname;?></td>
                    <td><?= $me->middlename;?></td>
                    <td><?= $me->lastname;?></td>
                    <td><?= $me->gender;?></td>
                     <td><?= $me->location;?></td>
                    <td>
                      <!--
                      <div class="btn-group">
                        <a class="btn btn-primary" href="#" alt="text" title="view"><i class="icon_plus_alt2"></i></a>
                        <a class="btn btn-success" href="viewidp.php?idp_Id=<?= $me->idp_Id?>"><i class="icon_check_alt2" title="update"></i></a>
                        <a class="btn btn-danger" href="delete-idp.php?idp_Id=<?= $me->idp_Id?>"><i class="icon_close_alt2" title="delete"></i></a> --> 
                      </div>
                    </td> 
                    <?php endforeach?>
                  </tr>
                </tbody>
              </table>
              <div align="center"><h2 align="center"><b><?php echo "AGAM = ".$agam." || "."ABEGENA= ".$abegena." || "."ICHWA= ".$ichwa."" ?> </h2></div>
              <span><h3 align="center"><b><?php echo "TOTAL = ".$total ?></b></h3></span>
             </header>
           </section>
         </b>
     
     <!-- container section end -->
    
  <!-- javascripts -->
  <script src="js/jquery.js"></script>
  <script src="js/jquery-ui-1.10.4.min.js"></script>
  <script src="js/jquery-1.8.3.min.js"></script>
  <script type="text/javascript" src="js/jquery-ui-1.9.2.custom.min.js"></script>
  <!-- bootstrap -->
  <script src="js/bootstrap.min.js"></script>
  <!-- nice scroll -->
  <script src="js/jquery.scrollTo.min.js"></script>
  <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
  <!-- charts scripts -->
  <script src="assets/jquery-knob/js/jquery.knob.js"></script>
  <script src="js/jquery.sparkline.js" type="text/javascript"></script>
  <script src="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
  <script src="js/owl.carousel.js"></script>
  <!-- jQuery full calendar -->
  <<script src="js/fullcalendar.min.js"></script>
    <!-- Full Google Calendar - Calendar -->
    <script src="assets/fullcalendar/fullcalendar/fullcalendar.js"></script>
    <!--script for this page only-->
    <script src="js/calendar-custom.js"></script>
    <script src="js/jquery.rateit.min.js"></script>
    <!-- custom select -->
    <script src="js/jquery.customSelect.min.js"></script>
    <script src="assets/chart-master/Chart.js"></script>
    <script src="js/daterangepicker.js"></script>
    <script src="js/bootstrap-datepicker.js"></script>

    <!--custome script for all page-->
    <script src="js/scripts.js"></script>
    <!-- custom script for this page-->
    <script src="js/sparkline-chart.js"></script>
    <script src="js/easy-pie-chart.js"></script>
    <script src="js/jquery-jvectormap-1.2.2.min.js"></script>
    <script src="js/jquery-jvectormap-world-mill-en.js"></script>
    <script src="js/xcharts.min.js"></script>
    <script src="js/jquery.autosize.min.js"></script>
    <script src="js/jquery.placeholder.min.js"></script>
    <script src="js/gdp-data.js"></script>
    <script src="js/morris.min.js"></script>
    <script src="js/sparklines.js"></script>
    <script src="js/charts.js"></script>
    <script src="js/jquery.slimscroll.min.js"></script>
    <script>
      //knob
      $(function() {
        $(".knob").knob({
          'draw': function() {
            $(this.i).val(this.cv + '%')
          }
        })
      });

      //carousel
      $(document).ready(function() {
        $("#owl-slider").owlCarousel({
          navigation: true,
          slideSpeed: 300,
          paginationSpeed: 400,
          singleItem: true

        });
      });

      //custom select box

      $(function() {
        $('select.styled').customSelect();
      });

      /* ---------- Map ---------- */
      $(function() {
        $('#map').vectorMap({
          map: 'world_mill_en',
          series: {
            regions: [{
              values: gdpData,
              scale: ['#000', '#000'],
              normalizeFunction: 'polynomial'
            }]
          },
          backgroundColor: '#eef3f7',
          onLabelShow: function(e, el, code) {
            el.html(el.html() + ' (GDP - ' + gdpData[code] + ')');
          }
        });
      });
    </script>

</body>

</html>