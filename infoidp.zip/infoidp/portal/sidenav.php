<html>
<head>

</head>
<body>  
  <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu">
          <li class="active">
            <a class="" href="dashboard.php">
                          <i class="icon_house_alt"></i>
                          <span>Dashboard</span>
                      </a>
          </li>
          <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="icon_document_alt"></i>
                          <span>Add</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
              <li><a class="" href="register.php">IDPS</a></li>
              <li><a class="" href="staff.php">Staff</a></li>
              <li><a class="" href="#">Registrar</a></li>
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="icon_desktop"></i>
                          <span>View</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
              <li><a class="" href="allstaffs.php">Staff</a></li>
              <li><a class="" href="allidps.php">IDPS</a></li>
              <li><a class="" href="#">Registrar</a></li>
              <li><a class="" href="reg_inventory.php">Inventory</a></li>
            </ul>
          </li>
          <li>
            <a class="" href="donations.php">
                          <i class="icon_genius"></i>
                          <span>Donations</span>
                      </a>
          </li>
          <li>
            <a class="" href="inventory.php">
                          <i class="icon_piechart"></i>
                          <span>Inventory</span>
                      </a>

          </li>
          <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="icon_table"></i>
                          <span>IDP Reports</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
              <li><a class="" href="idpsreport_gender.php">By gender</a></li>
              <li><a class="" href="idpsreport_status.php">By status</a></li>
              <li><a class="" href="idpsreport_location.php">By CampLocation</a></li>
            </ul>
          </li>

          <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="icon_documents_alt"></i>
                          <span>Donation Report</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
              <li><a class="" href="donation_report.php"><span>By Month & Year</span></a></li>
              <li><a class="" href="all_donations_loc.php"><span>Locations</span></a></li>
            </ul>
          </li>

        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>
    <!--sidebar end-->

</body>
</html>