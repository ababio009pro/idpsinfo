<?php 
 require"db.php";
$sqlidp='SELECT * FROM idp';
$sqldonations='SELECT  SUM(amount) as count FROM donations';
$sqlinventory='SELECT * FROM inventory';
$sqlstaff='SELECT * FROM staff';

$statement= $connect->prepare($sqlidp);

//fetch total donations
$statement2=$connect->prepare($sqldonations);
$statement2->execute();
$donations=$statement2->fetch();

// $statement2 = $statement2->fetch();
$statement3=$connect->prepare($sqlinventory);
$statement4=$connect->prepare($sqlstaff);

$statement->execute();

$statement3->execute();
$statement4->execute();



$idp=$statement->rowCount();

// var_dump($donations['count']);
$inventory=$statement3->rowCount();
$staff=$statement4->rowCount();



?>

<div class="row">
          <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
            <div class="info-box blue-bg">
              <i class="fa fa-thumbs-o-up"></i>
              <div class="count"><?php echo $idp;?></div>
              <div class="title">Total IDPS</div>
            </div>
            <!--/.info-box-->
          </div>
          <!--/.col-->

          <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
            <div class="info-box green-bg">
              <i class="fa fa-shopping-cart"></i>
              <div class="count"><?php echo "$".$donations['count']."";?></div>
              <div class="title">Donations</div>
            </div>
            <!--/.info-box-->
          </div>
          <!--/.col-->

          <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
            <div class="info-box dark-bg">
              <i class="fa fa-cubes"></i>
              <div class="count"><?php echo $staff."";?></div>
              <div class="title">Total Staffs</div>
            </div>
            <!--/.info-box-->
          </div>
          <!--/.col-->

          <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
            <div class="info-box blue-bg">
              <i class="fa fa-thumbs-o-up "></i>
              <div class="count"><?php echo $inventory;?></div>
              <div class="title">Inventory</div>
            </div>
            <!--/.info-box-->
          </div>
          <!--/.col-->

</div>

        <!--/.row-->