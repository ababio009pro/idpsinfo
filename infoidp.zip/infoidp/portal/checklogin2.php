<?php 
require("db.php"); 
session_start();
 // Includes Login Script
  if(isset($_POST["login"])){
    if(empty($_POST["username"]) || empty($_POST["password"])){
    $message ="ALL FIELDS ARE REQUIRED";
   }
    else{

                    $username  = $_POST['username'];
                    $password   = $_POST['password'];
          
                  $sql = "SELECT * FROM staff WHERE username = :username AND password = :password ";

                    $stmt = $connect->prepare($sql); 
                    $stmt->execute([':username' => $username, ':password'=> $password]);
                    $count=$stmt->rowCount();
                    if($count<1)
                    {
                    $message="username or password invalid";
                    }else{
                    $row =$stmt->fetch(PDO::FETCH_OBJ);
                    $role=$row->role;
                  //  $firstname=$row->firstname;
                    if($role=="admin"){
                    $_SESSION["username"]=$username;
                    //$_SESSION['firstname']=$firstname;
                    $_SESSION["role"]=$role;
                   header("location:dashboard.php");
                    }else if($role=="registrar"){
                      $_SESSION["role"]=$role;
                     $_SESSION["username"]=$username;
                   header("location:dashboard.php");
                    }else if($role=="staff"){
                      $_SESSION["role"]=$role;
                      $_SESSION["username"]=$username;
                      header("location:dashboard.php");
                    }else{
                      echo "invalid login details";
                    }
                   
                    } 
                    
                    }}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Benue IDPS Information System">
  <meta name="author" content="ababio009">
  <meta name="keyword" content="IDPS, Donations, Children, Elderly, Information, System, Information System">
  

  <title>Login Page | Benue State IDPS Information System</title>
   <!-- favicon-->
   <link rel="shortcut icon" href="img/logo.jpg">
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
  <script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>

  <!-- bootstrap theme -->
  <link href="css/bootstrap-theme.css" rel="stylesheet">
  <!--external css-->
  <!-- font icon -->
  <link href="css/elegant-icons-style.css" rel="stylesheet" />
  <link href="css/font-awesome.css" rel="stylesheet" />
  <!-- Custom styles -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet" />
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    

</head>

<body class="login-img3-body">
 </br>
</br>
</br>
</br>
<div class="container">
        <div class="row">
          <div class="col-md-4 col-md-offset-4">
            <div class="login-panel panel panel-default">
              <div class="panel-heading">
                <h3 class="panel-title"><b>BENUE STATE IDPS INFORMATION SYSTEM</b></h3>
              </div>
              <ul class="nav nav-pills">
                <li class="active"><a data-toggle="pill" href="#home">Admin</a></li>
                <li><a data-toggle="pill" href="#menu2">Registrar</a></li>
                 <li><a data-toggle="pill" href="#menu3">Staff</a></li>
              </ul>
          <div class="tab-content">
                <!-- Department -->
                <div id="home" class="tab-pane fade in active">
                  <br />
                  <form method="post" name="admin_form">
                    <div id="home" class="input-group">
          <span class="input-group-addon"><i class="icon_profile"></i></span>
          <input type="text" name="username" class="form-control" placeholder="Username" autofocus>
        </div>
        <div class="input-group">
          <span class="input-group-addon"><i class="icon_key_alt"></i></span>
          <input type="password" name="password" class="form-control"  placeholder="Password">
        </div>
        <label class="checkbox">
                <input type="checkbox" value="remember-me"> Remember me
            </label>
        <button class="btn btn-primary btn-lg btn-block" type="submit" name="login">Login</button>
        <a class="btn btn-primary btn-lg btn-block" href="/infoidp/index.php">Home</a> 
       <?php if(!empty($message)): ?>
      <div class="alert alert-danger">
    <div align="center" ><?php echo $message;?>
  </div>
     <?php endif;?>
      </div>
    </div>
    </div>
    </div>
                  </form>
                </div>
                <div id="menu2" class="tab-pane fade">
                  <br />
                  <form method="post" name="cashier_form">
                    <div id="menu2" class="input-group">
          <span class="input-group-addon"><i class="icon_profile"></i></span>
          <input type="text" name="username" class="form-control" placeholder="Username" autofocus>
        </div>
        <div class="input-group">
          <span class="input-group-addon"><i class="icon_key_alt"></i></span>
          <input type="password" name="password" class="form-control"  placeholder="Password">
        </div>
        <label class="checkbox">
                <input type="checkbox" value="remember-me"> Remember me
            </label>
        <button class="btn btn-primary btn-lg btn-block" type="submit" name="login">Login</button>
        <a class="btn btn-primary btn-lg btn-block" href="/infoidp/index.php">Home</a> 
       <?php if(!empty($message)): ?>
      <div class="alert alert-danger">
    <div align="center" ><?php echo $message;?>
  </div>
     <?php endif;?>
      </div>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
                </form>
                </div>
                <div id="menu3" class="tab-pane fade">
                  <br />
                  <form method="post" name="cashier_form">
                    <div id="menu2" class="input-group">
          <span class="input-group-addon"><i class="icon_profile"></i></span>
          <input type="text" name="username" class="form-control" placeholder="Username" autofocus>
        </div>
        <div class="input-group">
          <span class="input-group-addon"><i class="icon_key_alt"></i></span>
          <input type="password" name="password" class="form-control"  placeholder="Password">
        </div>
        <label class="checkbox">
                <input type="checkbox" value="remember-me"> Remember me
            </label>
        <button class="btn btn-primary btn-lg btn-block" type="submit" name="login">Login</button>
        <a class="btn btn-primary btn-lg btn-block" href="/infoidp/index.php">Home</a> 
       <?php if(!empty($message)): ?>
      <div class="alert alert-danger">
    <div align="center" ><?php echo $message;?>
  </div>
     <?php endif;?>
      </div>
    </div>
    </div>
    </div>
                  </form>
              </div>
            </div>
          </div>
        </div>
      </div>
  

</body>
</html>
