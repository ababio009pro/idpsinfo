<?php 
session_start();
 $role=$_SESSION['role'];
if(!isset($_SESSION['username']) || !isset($_SESSION['role'])){
header("location:login.php"); // Redirecting To Home Page
}else{
  require ("db.php");
   if(isset($_POST["Publish"]))
   {
    if(empty($_POST["blogTitle"]) || empty($_POST["blogContent"]))
    {
      $msg = "blogtitle and blogcontent require"; 
    }
      else
      {
        //do nothing here enter try and catch something eeehehehe!

   $collect="b-";
   $blogid= uniqid($collect); 
   $blogAuthor = $_SESSION["username"];
   $blogTitle = $_POST["blogTitle"];
   $blogContent = $_POST["blogContent"];
   $blogDate = date("d,m,y");
   $blogCategory = $_POST["blogCategory"];
   $blogTags= $_POST["blogTags"];


    // our SQL statements
   $sql="INSERT INTO blog (blogid,blogAuthor, blogTitle, blogContent, blogDate, blogCategory, blogTags)
    VALUES (:blogid, :blogAuthor,:blogTitle,:blogContent,:blogTime,:blogCategory,:blogTags)";
    $stmt=$connect->prepare($sql);
 if($stmt->execute([":blogid"=>$blogid, ":blogAuthor"=>$blogAuthor, ":blogContent"=>$blogContent, ":blogDate"=>$blogDate, ":blogTags"=>$blogTags])){
   echo "<script>
          alert('Event Posted, click OK to continue');
          window.location.href='dashboard.php';
        </script>";
 }}}}
 
 ?>