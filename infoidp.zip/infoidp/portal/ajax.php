    <?php
    //Including Database configuration file.
    include "db.php";
    //Getting value of "search" variable from "script.js".
    if (isset($_POST['firstname'])) {
    //Search box value assigning to $Name variable.
       $firstname= $_POST['firstname'];
    //Search query.
       $statement = "SELECT firstname from idp WHERE firstname LIKE '%$firstname%' LIMIT 5";
    //Query execution
       //$ExecQuery = MySQLi_query($connect, $statement);
       $ExecQuery=$connect->prepare($statement);
       $ExecQuery->execute([':firstname'=>$firstname]);
    //Creating unordered list to display result.
       echo '
    <ul>
       ';

       //Fetching result from database.
$ababio= $ExecQuery->fetchAll(PDO::FETCH_OBJ);
      
           ?>
       <!-- Creating unordered list items.
            Calling javascript function named as "fill" found in "script.js" file.
            By passing fetched result as parameter. -->
       <li onclick='fill("<?php echo $ababio->firstname; ?>")'>
       <a>
       <!-- Assigning searched result in "Search box" in "dashboard.php" file. -->
           <?php echo $ababio['firstname']; ?>
       </li></a>
       <!-- Below php code is just for closing parenthesis. Don't be confused. -->
       <?php
    }
    ?>
    </ul>