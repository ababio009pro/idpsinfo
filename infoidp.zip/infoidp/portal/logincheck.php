<?php	
require("db.php"); 
session_start();
 // Includes Login Script
	if(isset($_POST["login"])){
	  if(empty($_POST["username"]) || empty($_POST["password"])){
		$message ="ALL FIELDS ARE REQUIRED";
	 }
		else{

                    $username  = $_POST['username'];
                    $password   = $_POST['password'];
          
                  $sql = "SELECT * FROM staff WHERE username = :username AND password = :password ";

                    $stmt = $connect->prepare($sql); 
                    $stmt->execute([':username' => $username, ':password'=> $password]);
                    $count=$stmt->rowCount();
                    if($count<1)
                    {
                    $message="username or password invalid";
                    }else{
                    $row =$stmt->fetch(PDO::FETCH_OBJ);
                    $role=$row->role;
                  //  $firstname=$row->firstname;
                    if($role=="admin"){
                    $_SESSION["username"]=$username;
                    //$_SESSION['firstname']=$firstname;
                    $_SESSION["role"]=$role;
                   header("location:dashboard.php");
                    }else if($role=="registrar"){
                      $_SESSION["role"]=$role;
                     $_SESSION["username"]=$username;
                   header("location:dashboard.php");
                    }else if($role=="staff"){
                      $_SESSION["role"]=$role;
                      $_SESSION["username"]=$username;
                      header("location:dashboard.php");
                    }else{
                      echo "invalid login details";
                    }
                   
                } 
                  
              }
          }
               
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Benue IDPS Information System">
  <meta name="author" content="ababio009">
  <meta name="keyword" content="IDPS, Donations, Children, Elderly, Information, System, Information System">
  

  <title>Login Page | Benue State IDPS Information System</title>
   <!-- favicon-->
   <link rel="shortcut icon" href="img/logo.jpg">
  <!-- Bootstrap CSS -->
  <link rel="shortcut icon" href="img/logo.jpg">
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- bootstrap theme -->
  <link href="css/bootstrap-theme.css" rel="stylesheet">
  <!--external css-->
  <!-- font icon -->
  <link href="css/elegant-icons-style.css" rel="stylesheet" />
  <link href="css/font-awesome.css" rel="stylesheet" />
  <!-- Custom styles -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet" />
	
</head>
<body class="login-img3-body">
<div align="center">
  <div class="container" align="content">
<div class="container">
        <div class="row">
          <div class="col-md-4 col-md-offset-4">
            <div class="login-panel panel panel-default">
              <div class="panel-heading">
                <h3 class="panel-title" align="center"><b>LOGIN HERE</b></h3>
              </div>
              <ul class="nav nav-pills">
                <li class="active"><a data-toggle="pill" href="#home">Admin</a></li>
                <li><a data-toggle="pill" href="#menu2">Registrar</a></li>
                <li><a data-toggle="pill" href="#menu3">Staff</a></li>
              </ul>
              <div class="tab-content">
                <!-- admin staff and registrar Users login -->
                <div id="home" class="tab-pane fade in active">
                  <br/>
                  <form method="post" name="admin_form" action="">
                    <div class="form-group">
                      <input type="text" class="form-control" name="username" placeholder="Username">
                    </div>
                    <div class="form-group">
                      <input type="password" class="form-control" name="password" placeholder="Password">
                    </div>
                    <div class="form-group">
                      <button class="btn btn-block btn-success" id = "btn-login" name = "btn-login">Log in</button>
                      <button class="btn btn-block btn-success" id = "btn" name = "btn"><a href="infoidp/index.php">Go home</a></button>
                    </div>
                    <div class="form-group" id="alert-msg">
                 </div>

                  </form>
                </div>
                <div id="menu2" class="tab-pane fade">
                  <br />
                  <form method="post" name="registrar_form">
                    <div class="form-group">
                      <input type="text" class="form-control" name="username" placeholder="Username">
                    </div>
                    <div class="form-group">
                      <input type="password" class="form-control" name="password" placeholder="Password">
                    </div>
                    <div class="form-group">
                      <button class="btn btn-block btn-success" id = "btn" name = "btn">Log in</button>
                      <button class="btn btn-block btn-success" id = "btn" name = "btn"><a href="infoidp/index.php">Go home</a></button>
                    </div>
                    <div class="form-group" id="alert-msg1">
                    </div>
                  </form>
                </div>
                <div id="menu3" class="tab-pane fade">
                  <br />
                  <form method="post" name="staff_form">
                    <div class="form-group">
                      <input type="text" class="form-control" name="username" placeholder="Username">
                    </div>
                    <div class="form-group">
                      <input type="password" class="form-control" name="password" placeholder="Password">
                    </div>
                    <div class="form-group">
                      <button class="btn btn-block btn-success" id = "btn" name = "btn">Log in</button>
                      <button class="btn btn-block btn-success" id = "btn" name = "btn"><a href="infoidp/index.php">Go home</a></button>
                    </div>
                    <div class="form-group" id="alert-msg1">
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="text-right">
       <div class="credits">
          Designed by <a href="https://m.facebook.com/ababio009" action="blank" >Ababio009</a>
        </div>
    </div>
  </div>

<!-- jQuery -->
      <script src="../vendor/jquery/jquery.min.js"></script>

      <!-- Bootstrap Core JavaScript -->
      <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

      <!-- Metis Menu Plugin JavaScript -->
      <script src="../vendor/metisMenu/metisMenu.min.js"></script>

      <!-- Custom Theme JavaScript -->
      <script src="../dist/js/sb-admin-2.js"></script>

      <script type="text/javascript">
        jQuery(function(){
          $('form[name="admin_form"]').on('submit', function(donard){
            donard.preventDefault();

            var a = $(this).find('input[name="username"]').val();
            var b = $(this).find('input[name="pass"]').val();

            if (a === '' && b ===''){
              $('#alert-msg').html('<div class="alert alert-danger">All fields are required!</div>');
            }else{
              $.ajax({
                type: 'POST',
                url: 'new_login.php',
                data: {
                  username: a,
                  password: b
                },
                beforeSend:  function(){
                  $('#alert-msg').html('');
                }
              })
              .done(function(donard){
                if (donard == 0){
                  $('#alert-msg').html('<div class="alert alert-danger">Incorrect username or password!</div>');
                }else{
                  $("#btn-login").html('<img src="loading.gif" /> &nbsp; Signing In ...');
                  setTimeout(' window.location.href = "home.php"; ',2000);
                }
              });
            }
          });

          $('form[name="cashier_form"]').on('submit', function(donard){
            donard.preventDefault();

            var a = $(this).find('input[name="cashier_username"]').val();
            var b = $(this).find('input[name="cashier_pass"]').val();

            if (a === '' && b ===''){
              $('#alert-msg1').html('<div class="alert alert-danger">All fields are required!</div>');
            }else{
              $.ajax({
                type: 'POST',
                url: 'cashier/new_login.php',
                data: {
                  username: a,
                  password: b
                },
                beforeSend:  function(){
                  $('#alert-msg1').html('');
                }
              })
              .done(function(donard){
                if (donard == 0){
                  $('#alert-msg1').html('<div class="alert alert-danger">Incorrect username or password!</div>');
                }else{
                  $("#btn").html('<img src="loading.gif" /> &nbsp; Signing In ...');
                  setTimeout(' window.location.href = "cashier/sales.php?id=cash&invoice=<?php echo $finalcode ?>"; ',2000);
                }
              });
            }
          });
        });
      </script>
</body>

</html>
