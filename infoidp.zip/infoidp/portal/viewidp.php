<?php 
session_start();
 $role=$_SESSION['role'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Benue IDPS Information System">
  <meta name="author" content="ababio009">
  <meta name="keyword" content="IDPS, Donations, Children, Elderly, Information, System, Information System">
  <link rel="shortcut icon" href="img/favicon.png">

  <title>IDP| IDPS- Information System  </title>

  <!-- Bootstrap CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- bootstrap theme -->
  <link href="css/bootstrap-theme.css" rel="stylesheet">
  <!--external css-->
  <!-- font icon -->
  <link href="css/elegant-icons-style.css" rel="stylesheet" />
  <link href="css/font-awesome.min.css" rel="stylesheet" />
  <!-- full calendar css-->
  <link href="assets/fullcalendar/fullcalendar/bootstrap-fullcalendar.css" rel="stylesheet" />
  <link href="assets/fullcalendar/fullcalendar/fullcalendar.css" rel="stylesheet" />
  <!-- easy pie chart-->
  <link href="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen" />
  <!-- owl carousel -->
  <link rel="stylesheet" href="css/owl.carousel.css" type="text/css">
  <link href="css/jquery-jvectormap-1.2.2.css" rel="stylesheet">
  <!-- date -->
  <link href="css/daterangepicker.css" rel="stylesheet" />
  <link href="css/bootstrap-datepicker.css" rel="stylesheet" />
  <link href="css/bootstrap-colorpicker.css" rel="stylesheet" />
  <!-- Custom styles -->
  <link rel="stylesheet" href="css/fullcalendar.css">
  <link href="css/widgets.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet" />
  <link href="css/xcharts.min.css" rel=" stylesheet">
  <link href="css/jquery-ui-1.10.4.min.css" rel="stylesheet">
</head>

<body>

  <!-- container section start -->
  <section id="container" class="">
  
    <header class="header dark-bg">
      <div class="toggle-nav">
        <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"><i class="icon_menu"></i></div>
      </div>

      <!--logo start-->
      <a href="dashboard.php" class="logo">IDPS<span class="lite">Admin</span></a>
      <!--logo end-->

      <div class="nav search-row" id="top_menu">
        <!--  search form start -->
        <ul class="nav top-menu">
          <li>
            <form class="navbar-form">
              <input class="form-control" placeholder="Search" type="text">
            </form>
          </li>
        </ul>
        <!--  search form end -->
      </div>

      <div class="top-nav notification-row">
        <!-- notificatoin dropdown start-->
        <ul class="nav pull-right top-menu">

          <!-- task notificatoin start -->
          <li id="task_notificatoin_bar" class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                
          <!-- alert notification end-->
          <!-- user login dropdown start-->
          <li class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="profile-ava">
                                <img alt="" src="img/avatar1_small.jpg">
                            </span>
                            <span class="username"><?php echo $_SESSION['role']; ?></span>
                            <b class="caret"></b>
                        </a>
            <ul class="dropdown-menu extended logout">
              <div class="log-arrow-up"></div>
              <li class="eborder-top">
                <a href="#"><i class="icon_profile"></i> My Profile</a>
              </li>
              <li>
                <a href="logout.php"><i class="icon_key_alt"></i> Log Out</a>
              </li>
              <li>
                <a href="documentation.html"><i class="icon_key_alt"></i> Documentation</a>
              </li>
            </ul>
          </li>
          <!-- user login dropdown end -->
        </ul>
        <!-- notificatoin dropdown end-->
      </div>
    </header>
    <!--header end-->
     <?php 
 if($role=='admin'){
 require("sidenav.php");
}else if($role=='registrar'){
  require("sidenav_registrar.php");
}else if ($role=='staff'){
  require("sidenav_staff.php");
}
?>
    <!--header end-->

 <?php
  require'db.php';
  $idp_Id=$_GET['idp_Id'];
  $sql='SELECT * FROM idp WHERE idp_Id=:idp_Id';
  $statement=$connect->prepare($sql);
  $statement->execute([':idp_Id'=>$idp_Id]);
  $people=$statement->fetch(PDO::FETCH_OBJ);

  if(isset($_POST["UPDATE"])){ 
if(isset ($_POST['firstname']) && isset ($_POST['lastname'])){
$firstname  = $_POST['firstname'];
$middlename = $_POST['middlename'];
$lastname   = $_POST['lastname'];
$gender     = $_POST['gender'];
$soo        = $_POST['soo'];
$lga        = $_POST['lga'];
//$town       = $_POST['town'];
$address    = $_POST['address'];
$phone      = $_POST['phone'];
$dob        = $_POST['dob'];
$PGname      = $_POST['PGname'];
$PGsoo     = $_POST['PGsoo'];
$PGlga    = $_POST['PGlga'];
//$PGtown     = $_POST['PGtown'];
//$PGphone    = $_POST['PGphone'];
$relationship    = $_POST['Relationship'];
//$photo     = $_POST['photo'];
$location   =$_POST['location'];

$sqle='UPDATE idp SET firstname=:firstname, lastname=:lastname, gender=:gender, soo=:soo, address=:address, PGname=:PGname, PGsoo=:PGsoo, PGlga=:PGlga, relationship=:relationship WHERE idp_Id=:idp_Id';
$statemente=$connect->prepare($sqle);
if($statemente->execute([':firstname'=>$firstname, ':lastname'=>$lastname, ':gender'=>$gender, ':soo'=>$soo, ':address'=>$address,':PGname'=>$PGname, ':PGsoo'=>$PGsoo, ':PGlga'=>$PGlga, ':relationship'=>$relationship,':idp_Id'=>$idp_Id])){

  echo "<script>
              alert('Updated successfully, click OK to continue');
              window.location.href='allidps.php';
        </script>";
       
}
}
}

?>
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        <!--overview start-->
        <div class="row">
          <div class="col-lg-12">
          </div>
        </div>
        <!--overview start-->
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa-laptop"></i> Updating IDP <?php echo $people->firstname."".$people->lastname;?></h3>
            <ol class="breadcrumb">
              <li><i class="fa fa-home"></i><a href="dashboard.php">Home</a></li>
              <li><i class="fa fa-laptop"></i>Dashboard</li>
            </ol>
          </div>
        </div> 
     <!-- container section start -->
     <form id="form1" name="form1" method="post" action="">
  <table width="342" border="1" align="center">
    <tr>
      <td colspan="2" align="center"> <div class="card card1" ><img src="upload/Idps/<?php echo $people->photo;?>" width="150" height="150" alt="idp_photo" /></div></td>
    </tr>
    <tr>
      <td width="281">Firstname</td>
      <td width="45"><label for="firstname"></label>
      <input value="<?php echo $people->firstname; ?>" type="firstname"  name="firstname"/></td>
    </tr>
    <tr>
      <td>Middlename</td>
      <td><input value="<?php echo $people->middlename; ?>" type="middlename"  name="middlename" /></td>
    </tr>
    <tr>
      <td>Lastname</td>
      <td><input value="<?php echo $people->lastname; ?>" type="lastname"  name="lastname" /></td>
    </tr>
    <tr>
      <td>Gender</td>
      <td><input value="<?php echo $people->gender; ?>" type="gender"  name="gender" /></td>
    </tr>
    <tr>
      <td>State of Origin</td>
      <td><input value="<?php echo $people->soo; ?>" type="soo"  name="soo" /></td>
    </tr>
    <tr>
      <td>LGA</td>
      <td><input value="<?php echo $people->lga; ?>" type="lga"  name="lga" /></td>
    </tr>
    <tr>
      <td>Phone</td>
      <td><input value="<?php echo $people->phone; ?>" type="phone"  name="phone" /></td>
    </tr>
    <tr>
      <td>Contact Address</td>
      <td><label for="textarea"></label>
      <textarea value="<?php echo $people->address; ?>" name="address" id="address" cols="35" rows="3"></textarea></td>
    </tr>
    <tr>
      <td colspan="2" align="center"><strong>CONTACT INFORMATION</strong></td>
    </tr>
    <tr>
      <td>Parent Name</td>
      <td><input value="<?php echo $people->PGname; ?>" type="PGname" name="PGname" /></td>
    </tr>
    <tr>
      <td>State of Origin</td>
      <td><input type="text" value="<?php echo $people->PGsoo; ?>" type="PGsoo" name="PGsoo"/></td>
    </tr>
    <tr>
      <td>LGA</td>
      <td><input type="text" value="<?php echo $people->PGlga; ?>" type="PGlga" name="PGlga"/></td>
    </tr>
    <tr>
      <td>Relationship</td>
      <td><input type="text" value="<?php echo $people->relationship; ?>" type="Relationship" name="Relationship"/></td>
    </tr>
    <tr>
      <td colspan="2" align="center"><strong>OFFICAL INFO</strong></td>
    </tr>
    <tr>
      <td>Location</td>
      <td><select name="location" id="location" >
          <option value="1">--select one--</option>
          <option value="Agam">Agam</option>
          <option value="Abegena">Abagena </option>
          <option value="Ichwa">Ichwa</option>
      </select>
    </td>
  </tr>
  <tr>
    <td align="center"><input type="submit"  class="btn btn-info" name="UPDATE" id="UPDATE USER" value="UPDATE IDP" /></td>
  </tr>

  </table>
</form>
     <!-- container section end -->
     
     
  <!-- javascripts -->
  <script src="js/jquery.js"></script>
  <script src="js/jquery-ui-1.10.4.min.js"></script>
  <script src="js/jquery-1.8.3.min.js"></script>
  <script type="text/javascript" src="js/jquery-ui-1.9.2.custom.min.js"></script>
  <!-- bootstrap -->
  <script src="js/bootstrap.min.js"></script>
  <!-- nice scroll -->
  <script src="js/jquery.scrollTo.min.js"></script>
  <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
  <!-- charts scripts -->
  <script src="assets/jquery-knob/js/jquery.knob.js"></script>
  <script src="js/jquery.sparkline.js" type="text/javascript"></script>
  <script src="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
  <script src="js/owl.carousel.js"></script>
  <!-- jQuery full calendar -->
  <<script src="js/fullcalendar.min.js"></script>
    <!-- Full Google Calendar - Calendar -->
    <script src="assets/fullcalendar/fullcalendar/fullcalendar.js"></script>
    <!--script for this page only-->
    <script src="js/calendar-custom.js"></script>
    <script src="js/jquery.rateit.min.js"></script>
    <!-- custom select -->
    <script src="js/jquery.customSelect.min.js"></script>
    <script src="assets/chart-master/Chart.js"></script>
    <script src="js/daterangepicker.js"></script>
    <script src="js/bootstrap-datepicker.js"></script>

    <!--custome script for all page-->
    <script src="js/scripts.js"></script>
    <!-- custom script for this page-->
    <script src="js/sparkline-chart.js"></script>
    <script src="js/easy-pie-chart.js"></script>
    <script src="js/jquery-jvectormap-1.2.2.min.js"></script>
    <script src="js/jquery-jvectormap-world-mill-en.js"></script>
    <script src="js/xcharts.min.js"></script>
    <script src="js/jquery.autosize.min.js"></script>
    <script src="js/jquery.placeholder.min.js"></script>
    <script src="js/gdp-data.js"></script>
    <script src="js/morris.min.js"></script>
    <script src="js/sparklines.js"></script>
    <script src="js/charts.js"></script>
    <script src="js/jquery.slimscroll.min.js"></script>
    <script>
      //knob
      $(function() {
        $(".knob").knob({
          'draw': function() {
            $(this.i).val(this.cv + '%')
          }
        })
      });

      //carousel
      $(document).ready(function() {
        $("#owl-slider").owlCarousel({
          navigation: true,
          slideSpeed: 300,
          paginationSpeed: 400,
          singleItem: true

        });
      });

      //custom select box

      $(function() {
        $('select.styled').customSelect();
      });

      /* ---------- Map ---------- */
      $(function() {
        $('#map').vectorMap({
          map: 'world_mill_en',
          series: {
            regions: [{
              values: gdpData,
              scale: ['#000', '#000'],
              normalizeFunction: 'polynomial'
            }]
          },
          backgroundColor: '#eef3f7',
          onLabelShow: function(e, el, code) {
            el.html(el.html() + ' (GDP - ' + gdpData[code] + ')');
          }
        });
      });
    </script>

</body>

</html>