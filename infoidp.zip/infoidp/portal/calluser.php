<?php 
try{
  require"db.php";
$sql='SELECT * FROM user';
$statement=$connect->prepare($sql);
$statement->execute();
$people=$statement->fetchAll(PDO::FETCH_OBJ);


}catch(PDOException $e){
  echo('i don catch').$e->getmessage();
}

?>