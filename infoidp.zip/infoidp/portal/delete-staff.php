<?php
require'db.php';
$staffId=$_GET['staffId'];
$sql='DELETE FROM staff where staffId=:staffId';
$statement=$connect->prepare($sql);
if($statement->execute(['staffId'=>$staffId])
){
	
      echo "<script>
              alert('Deleted!!!, click OK to continue');
              window.location.href='allstaffs.php';
             </script>";                    
	//header("location:viewall.php");
}

?>