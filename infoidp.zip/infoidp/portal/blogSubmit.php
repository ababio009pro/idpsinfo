<?php
    session_start();
    require 'db.php';
	$username=$_SESSION['username'];
    $role=$_SESSION['role'];

	if(!isset($_SESSION['username']) AND $_SESSION['role'] == 0)
	{
		$_SESSION['role'] = "You need to first login to write a blog !!!";
		header("Location:404.php");
		die();
	}


	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		$Blogid= $_POST['post'];
		$Blogtitle = dataFilter($_POST['blogTitle']);
		$Blogcontent = $_POST['blogContent'];
		$Blogauthor = $_POST['role'];
		$Blogcategory = $_POST['BlogCategory'];
		$Blogtags = $_POST['BlogTags'];
		$Blogtime =getdate();
	}


    $sql = "INSERT INTO blog (blogid, blogAuthor, blogTitle, blogContent, BlogTime, BlogCategory, BlogTags)
		    VALUES ('$Blogid', '$Blogauthor', '$Blogtitle','$Blogcontent', '$Blogtime','$Blogcategory', '$Blogtags')";
    $result = mysqli_query($connect, $sql);

    if(!$result)
    {
        $_SESSION['message'] = "Some Error occurred !!!";
        header("location:dashboard.php");
    }
	else
	{  
		echo  "<script>
              alert('Event posted, click OK to continue');
              window.location.href='../portal/dashboard.php';
               </script>";
	}

    function dataFilter($data)
    {
    	$data = trim($data);
     	$data = stripslashes($data);
    	$data = htmlspecialchars($data);
      	return $data;
    }

?>
