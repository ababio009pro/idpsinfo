<?php
		require("db.php");
		// mysqli_connect() function opens a new connection to the MySQL server.
		session_start();// Starting Session
// Storing Session
	$user_check = $_SESSION['login_user'];
    $session_id  = $_SESSION['SESS_MEMBER_ID'];

// SQL Query To Fetch Complete Information Of User
	$query = $connect->prepare("SELECT * FROM user WHERE id = ?");
	$query->execute(array($session_id));
	$row = $query->fetch();

	$session_admin_name = $row['firstname'];
?>