<?php	
require("db.php"); 
session_start();
 // Includes Login Script
	if(isset($_POST["login"])){
	  if(empty($_POST["username"]) || empty($_POST["password"]) || empty($_POST['role'])){
		$message ="ALL FIELDS ARE REQUIRED";
	 }
		else{

                    $username   = $_POST['username'];
                    $password   = $_POST['password'];
                    $role       = $_POST['role'];
          
                    $sql = "SELECT * FROM user WHERE role = :role AND username = :username AND password = :password ";
                   // $sqlf = "SELECT * FROM user WHERE username = :username AND password = :password ";
                    /*$adminsql="SELECT password from user WHERE id=:id";
                    $stnath=$connect->prepare($stnath);
                    $stnath->execute([':password'=>$adminsql]);
                    $row1 =$stnath->fetch(PDO::FETCH_OBJ);
                    $role1=$row1->role*/

                    $stmt = $connect->prepare($sql); 
                    $stmt->execute([':role' => $role, ':username' => $username, ':password'=> $password]);
                    $count=$stmt->rowCount();
                    if($count<1)
                    {
                    $message="username or password invalid";
                    }else{
                    $row =$stmt->fetch(PDO::FETCH_OBJ);
                    $role=$row->role;
                  //  $firstname=$row->firstname;
                    if($role=="admin"){
                    $_SESSION["username"]=$username;
                    //$_SESSION['firstname']=$firstname;
                    $_SESSION["role"]=$role;
                   header("location:dashboard.php");
                    }else if($role=="registrar"){
                      $_SESSION["role"]=$role;
                     $_SESSION["username"]=$username;
                   header("location:dashboard.php");
                    }else if($role=="staff"){
                      $_SESSION["role"]=$role;
                      $_SESSION["username"]=$username;
                      header("location:dashboard.php");
                    }else{
                      echo "invalid login details";
                    }
                   
                    } 
                    
                    }}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Benue IDPS Information System">
  <meta name="author" content="ababio009">
  <meta name="keyword" content="IDPS, Donations, Children, Elderly, Information, System, Information System">
  

  <title>Login Page | Benue State IDPS Information System</title>
   <!-- favicon-->
   <link rel="shortcut icon" href="img/logo.jpg">
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
  <script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>

  <!-- bootstrap theme -->
  <link href="css/bootstrap-theme.css" rel="stylesheet">
  <!--external css-->
  <!-- font icon -->
  <link href="css/elegant-icons-style.css" rel="stylesheet" />
  <link href="css/font-awesome.css" rel="stylesheet" />
  <!-- Custom styles -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet" />
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    

</head>

<body class="login-img3-body">

  <div class="container">
    <form class="login-form" method="post" action="">
      <div class="login-wrap">
        <p class="login-img"><i class="icon_lock_alt"></i></p>
         <li><p data-toggle="pill" href="#home">ADMIN/REGISTRAR/STAFF LOGIN</p></li>
            </br>
          <div id="home" class="input-group">
          <span class="input-group-addon"><p>Login as -></p><i class="icon_profile"></i></span>
           <select name="role" id="role">
          <option value="">--select one--</option>
          <option value="admin">Admin</option>
          <option value="registrar">Registrar</option>
           <option value="staff">Staff</option>
      </select>
         </select>
        </div>
        <div id="home" class="input-group">
          <span class="input-group-addon"><i class="icon_profile"></i></span>
          <input type="text" name="username" class="form-control" placeholder="Username" autofocus>
        </div>
        <div class="input-group">
          <span class="input-group-addon"><i class="icon_key_alt"></i></span>
          <input type="password" name="password" class="form-control"  placeholder="Password">
        </div>
        <label class="checkbox">
                <input type="checkbox" value="remember-me"> Remember me
            </label>
        <button class="btn btn-primary btn-lg btn-block" type="submit" name="login">Login</button>
        <a class="btn btn-primary btn-lg btn-block" href="/infoidp/index.php">Home</a> 
		   <?php if(!empty($message)): ?>
	    <div class="alert alert-danger">
		<div align="center" ><?php echo $message;?>
	</div>
     <?php endif;?>
      </div>
    </div>
	  </div>
	  </div>
</form>
	
    <div class="text-right">
      <div class="credits">
          Designed by <a href="https://m.facebook.com/ababio009" action="blank" >Ababio009</a>
        </div>
    </div>
  </div>


</body>

</html>
