<?php	
require("pig.php"); 
session_start();
 // Includes Login Script
	if(isset($_POST["staffenter"])){


                    $username  = $_POST['username'];
                    $password   = $_POST['password'];
          
                  $sql = "SELECT * FROM staff WHERE username = :username AND password = :password ";

                    $stmt = $connect->prepare($sql); 
                    $stmt->execute([':username' => $username, ':password'=> $password]);
                    $count=$stmt->rowCount();
                    if($count<1)
                    {
                    $message="username or password invalid";
                    }else{
                    $row =$stmt->fetch(PDO::FETCH_OBJ);
                    $role=$row->role;
                  //  $firstname=$row->firstname;
                    if($role=="staff"){
                    $_SESSION["username"]=$username;
                    //$_SESSION['firstname']=$firstname;
                    $_SESSION["role"]=$role;
                    echo "Welcome Admin";
                   header("location:/admin/staff/dashboard.php");
                    }
                    else{
                      echo "invalid login details";
                    }
                   
                    } 
                    
                    }
?>