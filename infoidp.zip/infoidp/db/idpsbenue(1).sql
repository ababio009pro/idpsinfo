-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 17, 2019 at 12:21 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `idpsbenue`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `blogid` varchar(25) NOT NULL,
  `blogAuthor` varchar(25) NOT NULL,
  `blogTitle` varchar(50) NOT NULL,
  `blogContent` varchar(250) NOT NULL,
  `blogDate` varchar(25) NOT NULL,
  `blogCategory` varchar(50) NOT NULL,
  `blogTags` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `donations`
--

CREATE TABLE `donations` (
  `donateID` varchar(25) NOT NULL,
  `amount` varchar(225) NOT NULL,
  `firstname` varchar(25) NOT NULL,
  `lastname` varchar(25) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `location` varchar(25) NOT NULL,
  `address` varchar(25) NOT NULL,
  `additionalNote` varchar(250) NOT NULL,
  `year` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donations`
--

INSERT INTO `donations` (`donateID`, `amount`, `firstname`, `lastname`, `phone`, `location`, `address`, `additionalNote`, `year`) VALUES
('m-5d4d93840a5fd', '100', 'foga', 'kater', '08167161142', 'Abegena', 'Kampala', 'collect in 2059', '07/17/2013'),
('m-5d4db6e9974cd', '10000', 'Okpe', 'Sunday', '07067353095', 'Abegena', 'Just behind me', 'For the needy', '07/25/2019'),
('m-5d4e644e5f362', '9000', 'okpe', 'jjfh', '070657955458', 'Abegena', 'Just behind me', 'cvff', '07/17/2016'),
('m-5d4e68c34a35a', '2000', 'Sammy ', 'Adoyi', '587555442', 'Agma', 'Abuja', 'sdffd', '07/17/2017'),
('m-5d51863e15bc8', '15000', 'Ikwue', 'Adole', '08096444231', 'Ichwa', 'ogobia ugboju', 'for the progress of humanity\r\n', '07/17/2018'),
('m-5d552a99dafdd', '100', 'Williams', 'Isika', '45524422', 'Abegena', 'ddvffvf', 'use am well ooo', '07/17/2019'),
('m-5d57c6a1172c5', '2000', 'Simon', 'Terver', '070657955458', 'Agma', 'mkd', 'noted', '08/17/2019'),
('m-5d5a890de6d8a', '10000', 'hfgf', 'hgffty', '9875459', 'Agma', 'hhffghh', 'for benefits of orphans', '08/19/2019'),
('m-5d5aa11277f59', '1000', 'Rose ', 'Okpe ', '07067353095 ', 'Abegena', 'Rose ', 'Just for donations ', '08/19/2019'),
('m-5d5f49d93cc33', '500', 'Simon', 'Terver', '08071297177', 'Abegena', 'Uniagric off  campus', 'hhddgc', '08/23/2019'),
('m-5d63add036438', '5000', 'Chubi', 'Wonder', '08116264810', 'Abegena', 'Uniagric off  campus', 'I will pay when i become a billionaire', '08/26/2019'),
('m-5d9f60f58e483', '1000', 'Augustine', 'Officer', '08071297177', 'Agma', 'Uniagric offfdd', 'for food', '10/10/2019');

-- --------------------------------------------------------

--
-- Table structure for table `idp`
--

CREATE TABLE `idp` (
  `idp_Id` varchar(25) NOT NULL,
  `firstname` varchar(25) NOT NULL,
  `middlename` varchar(25) NOT NULL,
  `lastname` varchar(25) NOT NULL,
  `gender` varchar(15) NOT NULL,
  `soo` varchar(25) NOT NULL,
  `lga` varchar(25) NOT NULL,
  `town` varchar(25) NOT NULL,
  `address` varchar(25) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `dob` varchar(25) NOT NULL,
  `PGname` varchar(50) NOT NULL,
  `PGsoo` varchar(50) NOT NULL,
  `PGlga` varchar(15) NOT NULL,
  `PGtown` varchar(25) NOT NULL,
  `PGphone` varchar(25) NOT NULL,
  `relationship` varchar(25) NOT NULL,
  `location` varchar(50) NOT NULL,
  `photo` varchar(50) NOT NULL,
  `status` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `idp`
--

INSERT INTO `idp` (`idp_Id`, `firstname`, `middlename`, `lastname`, `gender`, `soo`, `lga`, `town`, `address`, `phone`, `dob`, `PGname`, `PGsoo`, `PGlga`, `PGtown`, `PGphone`, `relationship`, `location`, `photo`, `status`) VALUES
('ben-Idp-5d46d4d5782c3', 'Araka', 'Araka', 'James', 'Female', 'Benue State', 'Khana', 'Makurdi', 'Near the psalmist ', '070657955458', '1994-08-15', 'James Peter', 'Benue', 'Makurdi', 'Makurdi', '0806859964', 'brother', 'agam', '', 'married'),
('ben-Idp-5d518886df1fc', 'achan', 'okeda', 'mike', 'Male', 'Benue State', 'otukpa', 'adoja', 'dddfgggg', '09093432232', '2019-08-06', 'achan james', 'Benue', 'otukpa', '', '0809934323', 'father', 'agam', '', 'Married'),
('ben-Idp-5d518ce4e26c6', 'Olakeche', 'Adukwu', 'Janet', 'Female', 'Benue State', 'Otukpo', 'Makurdi', 'Just checking you oout', '08160801532', '2019-11-05', 'SADAT Terso', 'Benue', 'okpokwu', 'Makurdi', '08104617850', 'brother', 'abegena', '', 'Single'),
('ben-Idp-5d59223133be7', 'Peter', 'Lawerance', 'Inedu', 'Male', 'Benue State', 'Makurdi', 'Makurdi', 'Behind Coke Villa, Makurd', '035247415', '1983-12-23', 'Lawerance Inedu', 'Benue State', 'okpokwu', 'Odujo', '445524422', 'brother', 'abegena', 'barak.jpg', 'Single'),
('ben-Idp-5d66a8edd3a88', 'Okpe', 'Godwin', 'Godwin', 'Male', 'Benue State', 'Otukpo', 'Makurdi', 'Mascotech Makurdi South C', '081400585610', '1992-01-29', 'Enoch Okpe', 'Benue State', 'Makurdi', 'Makurdi', '08024554452', 'brother', 'abegena', 'oppo-mobile-500x500.jpg', 'Widower'),
('ben-Idp-5d66ad5d5f126', 'Monday', 'Adikwu', 'Christopher ', 'Male', 'Benue State', 'Kwande', 'Adikpo', 'enter here ', '070657955458', '1995-07-29', 'Monday Adikwu', 'Benue State', 'adikpo', 'Odujo', '85575754', 'father', 'Ichwa', 'blue-wallpapers-25170-232873.jpg', 'Married'),
('ben-Idp-5d6fd10a40f27', 'Richael', 'Tse', 'Rita', 'Female', 'Benue State', 'Otukpo', 'Otukpo', 'ddf', '080452785454', '1989-11-04', 'Mike Tse', 'Benue State', 'Afikpo', 'Afikpo', '080544755455', 'father', 'Ichwa', 'IMG-20190318-WA0003.jpg', 'Single'),
('ben-Idp-5d6fd21fe9a88', 'Halima ', 'Owocho', 'Owocho', 'Female', 'Benue State', 'Apa', 'Otukpo', 'Behind the LGA state Hous', '08084485565', '1994-07-06', 'Owiocho Abdullama', 'Benue State', 'okpokwu', 'APa', '07065485452', 'son', 'Ichwa', 'IMG-20190318-WA0045.jpg', 'Widow'),
('ben-Idp-5d9f60a3d9c25', 'Augustine ', 'Ameh', 'Jr', 'Male', 'Benue State', 'Kwande', 'Otukpo', 'behind sentona', '08181726124', '2019-10-11', 'Terver Mtseve', 'Benue', 'Makurdi', 'Odujo', '07065485452', 'father', 'abegena', 'fffg.png', 'Single');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `inventId` varchar(25) NOT NULL,
  `inventItem` varchar(25) NOT NULL,
  `inventLocation` varchar(25) NOT NULL,
  `photo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`inventId`, `inventItem`, `inventLocation`, `photo`) VALUES
('ag1235', 'Mat', 'abagena', 'celebrate-the-game.png'),
('code123', 'Executive Chair', 'abagena', 'd071a1c7ca6277afe71cfd3db694a833.gif'),
('code126', 'fan ', 'agam', 'celebrate-the-game.png'),
('Han1235', 'Table', 'abagena', 'blue-wallpapers-25170-232873.jpg'),
('p452', 'chair', 'agam', 'd071a1c7ca6277afe71cfd3db694a833.gif');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staffId` varchar(25) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `dob` varchar(25) NOT NULL,
  `address` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `role` varchar(25) NOT NULL,
  `location` varchar(50) NOT NULL,
  `photo` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staffId`, `username`, `password`, `firstname`, `lastname`, `dob`, `address`, `email`, `phone`, `role`, `location`, `photo`) VALUES
('IDPs-STAFF-5d47e92f988dc', 'registrar', 'registrar', 'Peter', 'Emeka', '2019-08-26', 'imported house ', 'emekapeter@gmail.com', '4785545', 'registrar', '', ''),
('IDPs-STAFF-5d514526833d8', 'user5d514526833db', '', 'Rita', 'Opita', '1992-08-18', 'Behind the Industry House, Benue State Housing Est', 'ritatopita@gmail.com', '080455246262', 'Nurse', 'abegena', '1566122545.jpg'),
('IDPs-STAFF-5d518b9dc992b', 'user5d518b9dc992e', '', 'Ollo', 'Morgan', '1995-11-05', 'Near Wadata, Behins my house address', 'ollomorgan11@gmail.com', '08160801532', 'nurse', 'Ichwa', '1566122545.jpg'),
('IDPs-STAFF-5d53d2d52b40e', 'user5d53d2d52b414', '', 'Simon', 'Sughente', '2019-08-24', '        xddvd', 'simonsughente@gmail.com', '08181726124', 'Nurse 1', 'abegena', '1566122545.jpg'),
('IDPs-STAFF-5d67fe444aa22', 'user5d67fe444aa25', '', 'Simon', 'Enoch', '2019-08-30', '   Food', 'simonenoch@gmail.com', '0807721565', 'Officer ', 'Ichwa', '1566122545.jpg'),
('IDPs-STAFF-5d67ff70c9b16', 'user5d67ff70c9b1d', '', 'Raymond', 'Rita', '2019-08-28', 'oofhhf', 'raymondrita@gmail.com', '0805474552', 'nurse ', 'abegena', '1566122545.jpg'),
('IDPs-STAFF-5d680076d3b2e', 'user5d680076d3b32', '', 'foga', 'Chinedu', '2019-09-04', 'vycfdzs', 'samuelotokpa@gmail.com', '87412251', 'Police Man', 'abegena', '1566122545.jpg'),
('IDPs-STAFF-5d68057772a01', 'user5d68057772a06', '', 'Barka', 'Godwin', '2019-08-30', 'cddvg', 'sammyadoyi@gmail.com', 'james', 'Security', 'Ichwa', '1566122545.jpg'),
('IDPs-STAFF-5d681236799cf', 'user5d681236799d4', '', 'Chiboy', 'Chubi', '2019-08-29', 'fgffg', 'abelchinedu@gmail.com', '0824542542', 'Gate Man', 'abegena', ''),
('IDPs-STAFF-5d6816410ce73', 'user5d6816410ce7a', '', 'James', 'James ', '2020-09-30', 'dcdcdcdd', 'hh', '448854', 'h', 'abegena', ''),
('IDPs-STAFF-5d6817d4e56d4', 'user5d6817d4e56de', '', 'Simon', 'jjfh', '2019-08-29', '        James ', 'ababiookpe@gmail.com', '070657955458', 'Gate Man', 'abegena', 'IMG-20190318-WA0007.jpg'),
('IDPs-STAFF-5d6d751c96074', 'user5d6d751c96079', '', 'Joseph', 'Attah', '2005-06-20', 'Neadtr', 'Josephattah@gmail.com', '87585555', 'Staff', 'Ichwa', '1567454492.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(5) DEFAULT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `firstname` varchar(45) NOT NULL,
  `lastname` varchar(45) NOT NULL,
  `role` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `firstname`, `lastname`, `role`) VALUES
(1, 'admin', 'admin', 'okpe', 'Sunday', 'admin'),
(2, 'staff', 'staff', 'Paulina', 'Alome', 'staff'),
(4, 'registrar', 'registrar', 'joe bass', 'same guy', 'registrar');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`blogid`);

--
-- Indexes for table `donations`
--
ALTER TABLE `donations`
  ADD PRIMARY KEY (`donateID`);

--
-- Indexes for table `idp`
--
ALTER TABLE `idp`
  ADD PRIMARY KEY (`idp_Id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`inventId`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staffId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
