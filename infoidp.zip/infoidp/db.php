<?php
$dbhost='localhost';
$dbuser='root';
$dbname='idpsbenue';
$dbpass='ababio';
try {
	$connect=new PDO("mysql:localhost=$dbhost;dbname=$dbname", $dbuser, $dbpass);
	$connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
echo "Connection fail".$e->getmessage();	
}


?>