 <?php
    include('db.php');
    $result = $connect->prepare("SELECT * FROM idp ORDER BY firstname");
    $result->execute();
     for($i=0; $row = $result->fetch(); $i++){
    ?>
    <tr class="record">
    <td class = "hidden"><?php echo $row['lastname']; ?></td>  
    <td><?php echo $row['firstname']; ?></td>
    <td><?php echo $row['middlename']; ?></td>
    <td><?php echo $row['lastname']; ?></td>
    <td>
    <a class="btn btn-primary" href="view_customer_transaction.php?id=<?php echo $row['customer_name']; ?>"> 
             <i class = "fa fa-eye"></i>
      </a>
    </td>
    </tr>
<?php
 }
?>